﻿using Projekt_WPF.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Projekt_WPF.Filters
{
    public static class Filters
    {
       
    }
}
