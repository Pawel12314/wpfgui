﻿using Projekt_WPF.models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Projekt_WPF.ViewModel
{
    public class MyViewModel
    {
        public ObservableCollection<Category> categories { get; set; }
        
        public ObservableCollection<Entry> entries { get; set; }
        
        public ObservableCollection<Summary> summaryList { get; set; }

       

  

      

        public MyViewModel()
        {
            //MessageBox.Show("viewmodel created");
            categories = new ObservableCollection<Category>();
            entries = new ObservableCollection<Entry>();
            summaryList = new ObservableCollection<Summary>();
            /*
            categories = new ObservableCollection<Category>( Category.readFromFile("kategorie.json")  );
            entries = new ObservableCollection<Entry>( Entry.readFromFile("wpisy.json") );
            summaryList = new ObservableCollection<Summary>(Summary.readFromFile("summaries.json"));
            */
            //MessageBox.Show(wpisy[0].nazwa);
        }
        
    }
}
