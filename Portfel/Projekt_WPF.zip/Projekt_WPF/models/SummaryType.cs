﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt_WPF.models
{
    public enum SummaryType
    {
        OUTCOME_PIE,
        INCOME_PIE,
        COMAPRISON,
        COMPARISON_CATEGORY
    }
}
